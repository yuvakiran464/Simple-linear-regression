# simpleLinearRegression
simple Linear Regression Script


README
Ajit Chavhan
21/11/2020

Simple Linear Regression Program

File Structure:
readme.txt
delivery_time
salary_hike
analysis
Development Environment:
My script was developed RStudio Version 1.3.1056

Usage:
Install RStudio. Open file in RStudio and change the code according to you dataset for various situations and run it.


File Description 
delivery_time - Script file in R language 
salary_hike - Script file in R language 

objective:- 
1) Delivery_time -> Predict delivery time using sorting time 
2) Salary_hike -> Build a prediction model for Salary_hike

Build a simple linear regression model by performing EDA and do necessary transformations and select the best model using R or Python.
